*PADS-LIBRARY-SCH-DECALS-V9*

PTS647SK70SMTR2N_LFS          0     100   100 10 100 10 4 7 0 4 8
TIMESTAMP 2022.03.28.18.45.22
"Default Font"
"Default Font"
500   250   0 8 100 10 "Default Font"
REF-DES
500   150   0 8 100 10 "Default Font"
PART-TYPE
300   -300  0 12 100 10 "Default Font"
*
300   -400  0 12 100 10 "Default Font"
*
CIRCLE 2 10 0 -1
240   -100 
200   -100 
CIRCLE 2 10 0 -1
400   -100 
360   -100 
OPEN   2 10 0 -1
100   -200 
100   0    
OPEN   2 10 0 -1
100   -100 
200   -100 
OPEN   2 10 0 -1
400   -100 
500   -100 
OPEN   2 10 0 -1
500   -200 
500   0    
OPEN   2 10 0 -1
240   -90  
330   0    
T0     0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -50   0     0 2 0
T0     -200  0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -50   0     0 2 0
T600   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -50   0     0 2 0
T600   -200  0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -50   0     0 2 0

*END*